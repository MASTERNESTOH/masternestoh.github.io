MASTER NESTOH KENYA WEBSITE

1. Open index.html in a browser to preview the site.
2. Replace the # links for Instagram, TikTok and YouTube with your real profile URLs.
3. Replace 254700000000 with your WhatsApp number.
4. Replace your@email.com with your email.
5. To publish it, upload index.html to a web host and connect your domain (for example masternestoh.com or masternestoh.co.ke).

The site is responsive and works on phones and computers.
